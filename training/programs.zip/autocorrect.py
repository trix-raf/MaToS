import csv
import numpy as np


def load_dictionary(path="dictionary.tsv"):
    words, freqs = [], []
    with open(path) as f:
        r = csv.reader(f, delimiter="\t")
        next(r)
        for row in r:
            words.append(row[0])
            freqs.append(float(row[1]))
    return words, np.array(freqs)


DICT_WORDS, DICT_FREQS = load_dictionary()
FREQ_NORM = np.clip(DICT_FREQS, 0, 7) / 7.0


def weighted_edit_distance(a, b, cap=2.5):
    """
    Asymmetric Levenshtein:
      insertion (extra letter in observation)   = 1.0
      deletion  (missing letter in observation) = 0.6
      substitution                              = 1.0
      transposition                             = 0.8
    """
    if abs(len(a) - len(b)) > cap + 0.5:
        return cap + 1
    prev = [j * 1.0 for j in range(len(b) + 1)]
    prev2 = None
    for i, ca in enumerate(a, 1):
        curr = [i * 1.0] + [0.0] * len(b)
        for j, cb in enumerate(b, 1):
            ins = prev[j] + 1.0
            dele = curr[j - 1] + 0.6
            sub = prev[j - 1] + (0.0 if ca == cb else 1.0)
            cost = min(ins, dele, sub)
            if prev2 is not None and i > 1 and j > 1 \
                    and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]:
                cost = min(cost, prev2[j - 2] + 0.8)
            curr[j] = cost
        prev2 = prev
        prev = curr
    return prev[-1]


def candidates(chunk, top_k=5, max_dist=2.0):
    chunk = chunk.upper()
    # Single-letter chunks: the letter IS the word.
    # "I" is a pronoun, "A" is an article. Do not "correct" them into IN/IS/IT.
    if len(chunk) <= 1:
        return [(chunk, 0.9, 0.0)]
    scored = []
    min_len = max(2, len(chunk) - 2)

    for w, fn in zip(DICT_WORDS, FREQ_NORM):
        if len(w) < min_len:
            continue
        d = weighted_edit_distance(chunk, w, cap=max_dist)
        if d <= max_dist:
            score = float(fn) - 0.7 * (d ** 2)
            scored.append((w, score, d))

    best_dict_score = max((s for _, s, _ in scored), default=0.0)

    if not any(s[0] == chunk for s in scored):
        if best_dict_score >= 0.35:
            raw_score = max(0.25, best_dict_score * 0.85)
        else:
            raw_score = 0.55
        scored.append((chunk, raw_score, 0.0))

    seen = {}
    for w, s, d in scored:
        if w not in seen or s > seen[w][0]:
            seen[w] = (s, d)
    items = [(w, s, d) for w, (s, d) in seen.items()]

    items.sort(key=lambda x: -x[1])
    return items[:top_k]


def build_combinations(per_chunk_candidates, top_n=5):
    from itertools import product
    combos = []
    for combo in product(*per_chunk_candidates):
        words = [c[0] for c in combo]
        score = sum(c[1] for c in combo)
        combos.append((" ".join(words), score))
    combos.sort(key=lambda x: -x[1])
    return [c[0] for c in combos[:top_n]]